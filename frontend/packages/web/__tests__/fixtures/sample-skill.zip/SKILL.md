---
name: e2e-test-skill
description: A fixture skill used by Playwright tests
version: 0.1.0
keywords: [test, fixture]
---

# E2E Test Skill

This is a fixture skill body used in admin upload tests.
